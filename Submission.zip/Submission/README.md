These will be the following login Codes for the android app:
* Portia:  A2RVQ
* Jerry:   N4Kax

The website url is http://breadcrumbs.bioscientifica.com and the login is:

* Username: jackSmith@hotmail.co.uk
* Password: aurora44
